select _Month,_Year,sum(Gross_sales_amount) as Gross_sales_amount
from (

SELECT month(a.date) as _Month,year(a.date) as _Year, (a.sold_quantity * b.gross_price) as Gross_sales_amount
FROM fact_sales_monthly a
join fact_gross_price b
on a.product_code = b.product_code
join dim_customer c
on a.customer_code = c.customer_code
where c.customer = 'Atliq Exclusive' ) f

group by _Month , _Year
order by Gross_sales_amount desc 


