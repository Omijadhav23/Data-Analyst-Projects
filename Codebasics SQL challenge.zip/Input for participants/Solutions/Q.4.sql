with
P_2020 as(
select
distinct(product_code) as Pro_2020,
count(*) as Product_count
from fact_sales_monthly
where fiscal_year = 2020
group by Pro_2020 ),

P_2021 as (
select
distinct(product_code) as pro_2021,
count(*) as Product_count
from fact_sales_monthly
where fiscal_year = 2021
group by pro_2021)

select *,Product_count_2021-Product_count_2020 as Difference

from (
select c.segment,sum(a.Product_count) as Product_count_2020,sum(b.Product_count) as Product_count_2021
from P_2020 a
join P_2021 b
on  a.Pro_2020 = b.pro_2021
join dim_product c
on b.pro_2021 = c.product_code
group by c.segment) S
order by Difference desc
