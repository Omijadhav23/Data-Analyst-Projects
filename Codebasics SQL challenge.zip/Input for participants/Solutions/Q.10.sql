
with cte1 as
(select * ,
row_number() over(partition by division order by Total_sold_quantity desc) as rank_rder

from 
(
select b.division , a.product_code,b.product,sum(a.sold_quantity) as Total_sold_quantity
from fact_sales_monthly a
join dim_product b
on a.product_code = b.product_code
where a.fiscal_year = 2021
group by a.product_code , b.product , b.division) as g)

select * 
from cte1
where rank_rder<=3

