with 
A as(
SELECT 
product_code as A , sum(sold_quantity) as sum2020
FROM gdb023.fact_sales_monthly
where fiscal_year = 2020
group by A) ,

B as (
SELECT 
product_code as B , sum(sold_quantity) as sum2021
FROM gdb023.fact_sales_monthly
where fiscal_year = 2021
group by B)


select 
A.A as unique_products_2020,B.B as unique_products_2021,
case
when (sum2020/sum2021) >= 1 then 1
else
(sum2020/sum2021) 
end as percentage_chg
from A 
right join B
on A.A = B.B
order by percentage_chg desc


