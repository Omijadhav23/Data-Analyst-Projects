
with
cte2 as (
select channel,sum(v.gross_sales_mln) as gross_sales_mln
from(

SELECT customer_code,gross_price,sold_quantity,
(gross_price*sold_quantity) as gross_sales_mln
FROM fact_gross_price a
join fact_sales_monthly b
on a.product_code = b.product_code
where b.fiscal_year = 2021 and a.fiscal_year = 2021) as v
join dim_customer b
on v.customer_code = b.customer_code
group by channel
order by gross_sales_mln desc)

select *,(gross_sales_mln/(select sum(v.gross_sales_mln)
from(
SELECT customer_code,gross_price,sold_quantity,
(gross_price*sold_quantity) as gross_sales_mln
FROM fact_gross_price a
join fact_sales_monthly b
on a.product_code = b.product_code
where b.fiscal_year = 2021 and a.fiscal_year = 2021) as v
join dim_customer b
on v.customer_code = b.customer_code)*100) as percentages
from cte2



