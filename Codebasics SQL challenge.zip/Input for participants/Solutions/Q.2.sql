
select A.product as unique_Products_2020 , B.product as unique_Products_2021 ,
case
when (countB-CountA)>0 then (countA/countB) 
else 0
end as p
from (select 
d.product,count(*) as countA
from fact_gross_price f
join dim_product d
on f.product_code = d.product_code
where f.fiscal_year = 2020
group by d.product) A
right join (select
d.product,count(*) as countB
from fact_gross_price f
join dim_product d
on f.product_code = d.product_code
where f.fiscal_year = 2021
group by d.product) B
on A.product = B.product






