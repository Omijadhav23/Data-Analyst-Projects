with
cte1 as (

SELECT b.customer , avg(a.pre_invoice_discount_pct) as average_discount_percentage
FROM fact_pre_invoice_deductions a
join dim_customer b
on a.customer_code = b.customer_code
where market = 'India' and fiscal_year = 2021
group by b.customer) ,
cte2 as (
SELECT a.customer_code,b.customer , a.pre_invoice_discount_pct
FROM fact_pre_invoice_deductions a
join dim_customer b
on a.customer_code = b.customer_code
where market = 'India' and fiscal_year = 2021 )

select b.customer_code , b.customer , a.average_discount_percentage  
from cte1 a 
join cte2 b
on a.customer = b.customer
where b.pre_invoice_discount_pct >= a.average_discount_percentage
order by a.average_discount_percentage desc
limit 5





